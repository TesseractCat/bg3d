function spawn_point()
    return Vec3.new(5, 5, 5)
end