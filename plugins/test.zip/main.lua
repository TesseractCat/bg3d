require "test"

function start()
    lobby:system_chat(_VERSION .. " | " .. lobby:name())
    lobby:system_chat("EATING STORES")
    local pawn = lobby:create_pawn{name="Test pawn", position=spawn_point(), mesh="chess/pawn.gltf"}
    lobby:system_chat("Spawned pawn at the dawn: " .. pawn)
end